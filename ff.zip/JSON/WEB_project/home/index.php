<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Домашняя страница</title>
    <meta charset="UTF-8">
    <link href="../fonts/font.css" type="text/css" rel="stylesheet">
    <link href="styles.css" type="text/css" rel="stylesheet">
</head>

<body>
    <div class="island_menu">
        <img src="images/icon/house_icon.svg" alt="Кнопка домой">
        <img class="island_item" src="images/icon/profile_icon.svg" alt="Кнопка профиля">
        <img class="island_item" src="images/icon/add_icon.svg" alt="Новый пост">
    </div>
    <?php
    include 'template.php';

    $postsData = file_get_contents('../data/post.json');
    $posts = json_decode($postsData, true);

    $usersData = file_get_contents('../data/users.json');
    $usersList = json_decode($usersData, true);

    $users_data = [];
    foreach ($usersList as $user) {
        $users_data[$user['user_id']] = $user;
    }

    foreach ($posts as $post) {
        $user_post_id = $post['user_id'];
        if (isset($users_data[$user_post_id])) {
            $user = $users_data[$user_post_id];
            generatePost($post, $user);
        }
    }
    ?>
</body>

</html>