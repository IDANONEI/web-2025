<!DOCTYPE html>
<html lang="ru">

<head>
    <title>Профиль</title>
    <meta charset="UTF-8">
    <link href="../fonts/font.css" type="text/css" rel="stylesheet">
    <link href="styles.css" type="text/css" rel="stylesheet">
</head>

<body>
    <div class="island_menu">
        <img class="island_item" src="images/icon/house_icon.svg" alt="Кнопка домой">
        <img src="images/icon/profile_icon.svg" alt="Кнопка профиля">
        <img class="island_item" src="images/icon/add_icon.svg" alt="Новый пост">
    </div>
    <?php
    include 'template.php';

    $userId = $_GET['user'] ?? null;

    // if (!$userId) {
    //     die("Не передан параметр user");
    // }

    $postsData = file_get_contents('../data/post.json');
    $posts = json_decode($postsData, true);

    $usersData = file_get_contents('../data/users.json');
    $usersList = json_decode($usersData, true);

    // Ищем пользователя
    $userPostsIds = [];
    foreach ($usersList as $user) {
        if ($user['user_id'] == $userId) {
            $userPostsIds = $user['id_posts']; // массив id постов
            $users_data = $user;
            break;
        }
    }

    // // Проверка, нашли ли мы посты
    // if (empty($userPostsIds)) {
    //     die("Посты пользователя не найдены или пользователь не существует");
    // }

    // Ищем сами посты по ID
    $user_posts = [];
    foreach ($posts as $post) {
        if ($post['user_id'] == $userId) {
            $user_posts[] = $post;
        }
    }    

    generateProfile($users_data, $user_posts);

    ?>
</body>

</html>